/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package EnumerationDefinitions;

/**
 *
 * @author akutta
 */
public enum DistributionTypeEnum {
    GAUSSIAN,
    TRUNCATED_GAUSSIAN,
    NORMALIZED_RANDOM
}
