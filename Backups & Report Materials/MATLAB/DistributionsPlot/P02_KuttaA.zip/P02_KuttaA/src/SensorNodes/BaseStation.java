/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SensorNodes;

import WirelessSensorNetwork.WirelessSensorNetwork;

/**
 *
 * @author KuttaA
 */
public class BaseStation extends Node {
    private double joules;
    private WirelessSensorNetwork wsn;

    private Node[] nodeArray;


    public BaseStation(WirelessSensorNetwork wsn) {
        bClusterHead = true;
        posX = 0;
        posY = -100;
        this.wsn = wsn;
    }

    @Override
    public void setJoules(double newJoules) {
        joules = newJoules;
    }

    @Override
    Node findClosestClusterHead(Node sensor) {
        nodeArray = wsn.getNodes();
        Node curNode = null;
        Double closestDistance = -1.0;
        Double tmpDistance = -1.0;
        if ( sensor.isClusterHead() ) {
            return sensor;
        }  else {
            for ( int i = 0; i < nodeArray.length - 1; i++ ) {
                if ( nodeArray[i].isClusterHead() ) {
                    tmpDistance = sensor.getDistance(nodeArray[i]);
                    if ( closestDistance == -1 || tmpDistance < closestDistance) {
                        curNode = nodeArray[i];
                        closestDistance = tmpDistance;
                    } 
                }
            }
        }
        return curNode;
    }

    @Override
    Node findClosest(Node sensor) {
        Double closestDistance = sensor.getDistance(posX,posY);
        
        Node curNode = this;

        nodeArray = wsn.getNodes();
        for ( int i = 0; i < nodeArray.length - 1; i++ ) {
            if ( nodeArray[i] != sensor && nodeArray[i].getAlive() && nodeArray[i].isClusterHead() ) {
                if ( nodeArray[i].getPosY() < sensor.getPosY()  ) {        // Ensure the node is closer to base (Y coord only atm)

                    // Figure out which side of the board the node is
                    if ( nodeArray[i].getPosX() <= posX ) {
                        // Negative Side of the X-Axis
                        if ( sensor.getPosX() > nodeArray[i].getPosX() )
                        {
                            Double d = distance(nodeArray[i].getPosX(),nodeArray[i].getPosY(),
                                    sensor.getPosX(), sensor.getPosY());
                            if ( closestDistance > d )
                            {
                                closestDistance = d;
                                curNode = nodeArray[i];
                            }
                        }
                    } else if ( nodeArray[i].getPosX() > posX ) {
                        // Positive Side of the X-Axis
                        if ( sensor.getPosX() < nodeArray[i].getPosX() )
                        {
                            Double d = distance(nodeArray[i].getPosX(),nodeArray[i].getPosY(),
                                    sensor.getPosX(), sensor.getPosY());
                            if ( closestDistance > d )
                            {
                                closestDistance = d;
                                curNode = nodeArray[i];
                            }
                        }
                    }
                }
            }
        }

        //System.out.println("Closest Distance:\t" + closestDistance);
        return curNode;
    }

    Double distance(Integer x1, Integer y1, Integer x2, Integer y2) {
        Double x = Math.pow(x1.doubleValue()-x2.doubleValue(),2.0);
        Double y = Math.pow(y1.doubleValue()-y2.doubleValue(),2.0);
        return Math.sqrt(x + y);
    }
}
