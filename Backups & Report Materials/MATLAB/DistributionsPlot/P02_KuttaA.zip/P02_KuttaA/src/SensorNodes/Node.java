/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SensorNodes;

import EnumDefinitions.*;

/**
 *
 * @author KuttaA
 */
public class Node {
    protected Integer posX, posY;
    protected boolean bClusterHead;
    protected TransmitType tType;
    protected Float N;
    protected Integer roundsSinceClusterHead;

    public Integer getRoundsSinceClusterHead() {
        return roundsSinceClusterHead;
    }

    public void setRoundsSinceClusterHead(Integer roundsSinceClusterHead) {
        this.roundsSinceClusterHead = roundsSinceClusterHead;
    }

    public Float getN() {
        return N;
    }

    public void setN(Float N) {
        this.N = N;
    }

    public TransmitType getType() {
        return tType;
    }

    protected Node() {
        bClusterHead = true;
        posX = 0;
        posY = 0;
    }

    public Integer getPosX() {
        return posX;
    }

    public void setPosX(Integer posX) {
        this.posX = posX;
    }

    public Integer getPosY() {
        return posY;
    }

    public void setPosY(Integer posY) {
        this.posY = posY;
    }

    protected double getDistance(Node target) {
        return Math.sqrt(
                Math.pow(posX.doubleValue() - target.getPosX().doubleValue(),2.0) +
                Math.pow(posY.doubleValue() - target.getPosY().doubleValue(),2.0)
                );
    }
    
    protected double getDistance(Integer tarX, Integer tarY) {
        return Math.sqrt(Math.pow(posX.doubleValue() - tarX.doubleValue(),2.0) +
                Math.pow(posY.doubleValue() - tarY.doubleValue(),2.0));

    }

    public Double getJoules() {
        return -1.0;
    }


    public void setAlive(boolean b) {
        System.out.println("ERROR:\tShould Not Have Been Called\n\tNode::setAlive()");
    }

    public void setJoules(double newJoules) {
        System.out.println("ERROR:\tShould Not Have Been Called\n\tNode::setJoules()");
    }

    public void setType(TransmitType transmitType) {
        System.out.println("ERROR:\tShould Not Have Been Called\n\tNode::setType()");
    }

    public void transmit(Node base) {
        System.out.println("ERROR:\tShould Not Have Been Called\n\tNode::transmit()");
    }

    public Boolean getAlive() {
        System.out.println("ERROR:\tShould Not Have Been Called\n\tNode::getAlive()");
        return false;
    }

    void recieve(Node base) {
        System.out.println("ERROR:\tShould Not Have Been Called\n\tNode::recieve()\t");
    }

    Node findClosest(Node aThis) {
        System.out.println("ERROR:\tShould Not Have Been Called\n\tNode::findClosest()");
        return null;
    }

    Node findClosestClusterHead(Node sensor) {
        System.out.println("ERROR:\tShould Not Have Been Called\n\tNode::findClosest()");
        return null;
    }
    
    public void setClusterHead(Boolean bCH ) {
        bClusterHead = bCH;
    }

    public boolean isClusterHead() {
        return bClusterHead;
    }

    public void advertise(Integer NumberClusterHeads, Integer numNodes) {
        System.out.println("ERROR:\tShould Not Have Been Called\n\tNode::advertise()");
    }

    public void transmitToBase(Node base) {
        System.out.println("ERROR:\tShould Not Have Been Called\n\tNode::transmitToBase()");
    }

    public void computeFuseCost() {
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
