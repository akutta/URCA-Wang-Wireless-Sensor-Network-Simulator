/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SensorNodes;

import EnumDefinitions.*;
import java.util.Random;

/**
 *
 * @author KuttaA
 */
public class WirelessNode extends Node {
    private Random rand;
    private Boolean alive;
    private Double joules;
    private Integer messages = 0;

    private Integer k = 2000;           // Number of bits per transmit
    private double Eelec = 0.00000005;   // 50 nJ
    private double eAmp = 0.0000000001;   // 100 pJ

    public WirelessNode(Node copy) {
        joules = copy.getJoules();
        alive = copy.getAlive();
        posX = copy.getPosX();
        posY = copy.getPosY();
    }
    //
    // abs(minX) = maxX
    // minY = 0
    // maxY = radius
    //
    public WirelessNode(int minX,int minY, int maxX, int maxY, Double nanoJoules) {
        Eelec = nanoJoules * Math.pow(10.0, -9.0);
        //bClusterHead = true;
        alive = true;                           // All Wireless nodes Initially alive
        rand = new Random();
        posX = rand.nextInt(maxX * 2) + minX;   // Adjusts back to negative
        posY = rand.nextInt(maxY);              // Already from 0->maxY
    }
    @Override
    public void setAlive(boolean bAlive) {
        alive = bAlive;
    }

    @Override
    public void setType(TransmitType transmitType) {
        tType = transmitType;
    }

    private void doTransmit(Double distance) {
        Double deltaJ = k*(Eelec + eAmp * distance * distance);

        joules -= deltaJ;
        if ( joules <= 0 ) {
            joules = 0.0;
            alive = false;
        }
    }

    @Override
    public void transmitToBase(Node base) {
        Double distance = 0.0;
        distance = getDistance(base);
        doTransmit(distance);
    }

    @Override
    public void computeFuseCost() {
        // 5 nJ/bit/message
       
        Double nj = 5.0 * Math.pow(10.0, -9.0);
        Double deltaJ = messages * (nj / k);

        joules -= deltaJ;
        if ( joules <= 0 ) {
            joules = 0.0;
            alive = false;
        }

        messages = 0;
    }
    //
    // Assumes a 2000 bit message
    //
    @Override
    public void transmit(Node base) {
        if ( alive ) {
            Double distance = 0.0;

            if ( tType == TransmitType.DIRECT ) {
                distance = getDistance(base);
                doTransmit(distance);
            }  else if (tType == TransmitType.MULTIHOP) {
                //System.out.println("MULTIHOP");
                Node nextNode = base.findClosest(this);
                distance = getDistance(nextNode);

                if ( nextNode != base ) {
                    nextNode.recieve(base);
                }
                doTransmit(distance);
            } else if ( tType == TransmitType.LEACH ) {
                if ( this.isClusterHead() ) {
                    // Cluster heads don't instantly
                    // transmit data to base station
                } else {
                    Node clusterHead = base.findClosestClusterHead(this);
                    if ( clusterHead == null ) {
                    } else {
                        distance = getDistance(clusterHead);
                        clusterHead.recieve(base);
                    }
                    doTransmit(distance);
                }
            }
        }
    }

    @Override
    public Boolean getAlive() {
        return alive;
    }


    @Override
    public Double getJoules() {
        return joules;
    }

    @Override
    public void setJoules(double newJoules) {
        joules = newJoules;
    }

    @Override
    public void recieve(Node base) {
        if ( tType == TransmitType.LEACH ) {
            // Store the number of messages being sent
            messages++;
        }
        joules -= k * Eelec;
        if ( joules <= 0 )
            alive = false;
        transmit(base);
    }

    @Override
    public void advertise(Integer NumberClusterHeads, Integer numNodes) {
        Random ran = new Random();
        Float fRand = ran.nextFloat();

        if ( N == 0 ) 
            roundsSinceClusterHead = 1;

        Float T = N;
        Float divT = 1 - (N * (roundsSinceClusterHead %  (1/N)));
        T /= divT;

        bClusterHead = false;

        if ( alive ) {
           // if ( NumberClusterHeads < numNodes || N == 0.0f ) {    // Can't divide by 0.  0 = all nodes
            //System.out.println("NCH:\t" + NumberClusterHeads + "\t" + N * numNodes);
                if ( N == 0 )
                    bClusterHead = true;
                else {
                    if ( fRand < T ) {
                        bClusterHead = true;
                        roundsSinceClusterHead = 1;
                    } else {
                        bClusterHead = false;
                        roundsSinceClusterHead++;
                    }
                }
           // }
        } else
            bClusterHead = false;
    }
}
