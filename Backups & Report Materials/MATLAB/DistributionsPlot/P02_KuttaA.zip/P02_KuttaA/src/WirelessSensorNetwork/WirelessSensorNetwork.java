/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package WirelessSensorNetwork;

import EnumDefinitions.TransmitType;
import SensorNodes.*;
import java.io.FileOutputStream;
import java.io.PrintStream;

/**
 *
 * @author KuttaA
 */
public class WirelessSensorNetwork extends Board {
    private Node[] nodeArray;
    private TransmitType tType;
    private BaseStation base;
    private Double nJ;
    Integer totClusterHeads = 0;
    Integer runs = 0;
    Integer percentN = 5;

    public TransmitType gettType() {
        return tType;
    }

    public void settType(TransmitType tType) {
        this.tType = tType;
    }

    public WirelessSensorNetwork(int minRangeX, int maxRangeX, int minRangeY,
            int maxRangeY, int numNodes, Double nanoJoules) {
        minX = minRangeX;
        maxX = maxRangeX;
        minY = minRangeY;
        maxY = maxRangeY;
        numberOfNodes = numNodes;
        nJ = nanoJoules;
        initialize();

        base  = new BaseStation(this);
    }

    private void initialize() {
        nodeArray = new Node[numberOfNodes+1];
        for ( int i = 0; i < numberOfNodes; i++ ) {
            nodeArray[i] = new WirelessNode(minX,minY,maxX,maxY,nJ);
        }
    }


    public void outputNodeCoords(String outputName) {
        PrintStream p = null;
        try {
            FileOutputStream out = new FileOutputStream(outputName + "_NodesOutput.csv");
            p = new PrintStream(out);
            
            p.println("posX,posY,JoulesRemaining");

            for ( int i = 0; i < numberOfNodes; i++ ) {
                p.println(nodeArray[i].getPosX() + "," + nodeArray[i].getPosY() + "," + nodeArray[i].getJoules());
            }

            p.close();
        } catch (Exception e) {
                System.err.println ("Error writing to file:\tNodesOutput.csv");
        }
    }

    public void setType(TransmitType transmitType) {
        Integer iClusterHead = 0;
        tType = transmitType;
        // Reset the alive flags
        for ( int i = 0; i < numberOfNodes; i++ ) {
            nodeArray[i].setAlive(true);
            nodeArray[i].setType(transmitType);
            if ( tType == TransmitType.LEACH ) {
                nodeArray[i].setClusterHead(false);
                if ( percentN == null ) {
                    nodeArray[i].setN(0.05f); // 5%
                    nodeArray[i].setRoundsSinceClusterHead(0); // force all to be eligible for being a cluster head
                } else {
                    nodeArray[i].setN(percentN.floatValue() / 100);
                    Float maxRounds = (1 / nodeArray[i].getN());
                    if ( percentN != 0 ) {
                        //System.out.println("MaxRounds:\t" + maxRounds);
                        nodeArray[i].setRoundsSinceClusterHead(0); // force all to be eligible for being a cluster head
                    }
                }
                //nodeArray[i].advertise();
            } else {
                nodeArray[i].setClusterHead(true);
            }
        }
    }

    public void setInitialJoules(double newJoules) {
        for ( int i = 0; i < numberOfNodes; i++ ) {
            nodeArray[i].setJoules(newJoules);
        }
    }

    // Just so we don't run through for loops twice
    public void setTypeAndJoules(TransmitType transmitType, double newJoules) {
        tType = transmitType;
        // Reset the alive flags
        for ( int i = 0; i < numberOfNodes; i++ ) {
            nodeArray[i].setAlive(true);
            nodeArray[i].setJoules(newJoules);
            nodeArray[i].setType(transmitType);
        }
    }

    //
    // In all graphs,
    //      Direct and MTE were all dead by 500
    //      LEACH = 1400
    //
    public void runSimulation() {
        Integer iHead = 0;
        totClusterHeads = 0;
        if ( tType == TransmitType.LEACH ) {
            for ( int j = 0; j < numberOfNodes; j++ ) {
                nodeArray[j].advertise(totClusterHeads, percentN);
                if ( nodeArray[j].isClusterHead() ) {
                    totClusterHeads++;
                }
            }
        }
        for ( int j = 0; j < numberOfNodes; j++ ) {
            nodeArray[j].transmit(base);
        }
        runs++;
    }

    public Integer getAvgHeads() {
        return totClusterHeads / runs;
    }

    public Node[] getNodes() {
        return nodeArray;
    }

    public void leachTransmit() {
        for ( int i = 0; i < numberOfNodes; i++ ) {
            if ( nodeArray[i].isClusterHead() ) {
                // Compute the transmit cost to base
                //nodeArray[i].computeFuseCost();
                nodeArray[i].transmitToBase(base);
            }
        }
    }

    public void setN(Integer percentClusterHead) {
        percentN = percentClusterHead;
    }
}
