/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package p02_kuttaa;

import EnumDefinitions.TransmitType;
import SensorNodes.Node;
import WirelessSensorNetwork.WirelessSensorNetwork;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KuttaA
 */
public class WSNThread extends Thread {

    private TransmitType transmitType;
    
    public void setTransmitType(TransmitType tType ) {
        transmitType = tType;
    }

    public void SurveyLeach() {
        // Only care about these parameters
        WirelessSensorNetwork wsn = null;
        Integer diameter = 50;
        Double Joules = 50.0;

        dataStorageClass dsc[] = new dataStorageClass[100];
        for ( Integer i = 0; i < 100; i++ ) {
            dsc[i] = new dataStorageClass();
        }
        
        for ( Integer percentClusterHead = 0; percentClusterHead < 100; percentClusterHead++ ) {
            wsn = new WirelessSensorNetwork(
                -25, 25,        // Range X
                0, diameter,    // Range Y
                100,            // Num Nodes
                Joules          // )nanoJoules
                );

            // it is still a leach transmit scheme
            wsn.setN(percentClusterHead);
            wsn.setType(TransmitType.LEACH);
            wsn.setInitialJoules(0.5);

            for ( Integer Iterator = 0; Iterator < 1400; Iterator++ ) {
                wsn.runSimulation();
                if (  percentClusterHead == 5  ) {
                    if ( Iterator == 800 ) {
                        outputBoard(wsn.getNodes(), "a");
                    } else if ( Iterator == 1200 ) {
                        outputBoard(wsn.getNodes(), "b");
                    }
                }
                wsn.leachTransmit();
                if ( Iterator == 100 )
                    dsc[percentClusterHead].insertNodes(wsn.getNodes());
            }
            
        }

        FileWriter fstream;
        try {
            fstream = new FileWriter("LeachPercentCluster.csv", true);
            BufferedWriter out = new BufferedWriter(fstream);

            for ( Integer i = 0; i < 100; i++ ) {
                out.write(i + "," + dsc[i].getDissipatedSurvey() + "\n");
            }
            out.close();
        } catch (IOException e) {
        }
    }

    @Override
    public void run() {
        if ( transmitType == null ) {
            System.out.println("Must Set Transmit Type Before Running");
            return;
        }

        if ( transmitType == TransmitType.LEACHSURVEY ) {
            SurveyLeach();
            return;
        }

        try {
            DeleteCSVFile(transmitType);
        } catch (IOException ex) {
            Logger.getLogger(WSNStart.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // TODO code application logic here
        WirelessSensorNetwork wsn = null;
        Integer maxIterations = 500;
        if ( transmitType == TransmitType.LEACH ) {
            maxIterations = 1400;
        }

        for ( Integer diameter = 10; diameter <= 100; diameter += 10)
        {
            System.out.println("Diameter:\t" + diameter + "\t" + this);
            for ( Double Joules = 0.0; Joules <= 100; Joules += 10 )
            {
                // Force Garbage Collection
               System.gc();
               System.runFinalization();

                dataStorageClass dsc[] = new dataStorageClass[maxIterations];

                for ( int i = 0; i < maxIterations; i++ ) {
                    dsc[i] = new dataStorageClass();
                }
                
                for ( int i = 0; i < 10; i++ ) {
                    wsn = new WirelessSensorNetwork(
                        -25, 25,    // Range X
                        0, diameter,      // Range Y
                        100,        // Num Nodes
                        Joules        // )nanoJoules
                        );

                    // If it's a leach protocal
                    // setType will automatically determine which nodes 
                    // should be clusterheads.
                    wsn.setType(transmitType);
                    wsn.setInitialJoules(0.5);

                    for ( Integer Iteration = 0; Iteration < maxIterations; Iteration++ ) {
                        wsn.runSimulation();

                        if ( transmitType == TransmitType.LEACH ) {
                            wsn.leachTransmit();
                        }

                        dsc[Iteration].setDiameter(diameter);
                        dsc[Iteration].setEelec(Joules);
                        dsc[Iteration].setIteration(Iteration);
                        dsc[Iteration].insertNodes(wsn.getNodes());
                    }
                }

                //System.out.println("Average Cluster Heads:\t" + wsn.getAvgHeads());

                //outputEverything(dsc,transmitType + "AllData.csv");
                if ( diameter == 50.0 && Joules == 50.0 ) {
                    if ( Joules == 50.0 ) {
                        outputAlive(dsc,transmitType + "");
                        outputIteration(dsc,0,transmitType);
                        if ( transmitType == TransmitType.LEACH ) {
                            outputIteration(dsc,1200,transmitType);
                        } else
                            outputIteration(dsc,180,transmitType);
                    }
                }
                outputEnergyDissipated(dsc,transmitType);
            }
        }
    }

    private void outputEverything(dataStorageClass[] dsc, String fileName) {
            FileWriter fstream;
            try {
                fstream = new FileWriter(fileName, true);
                BufferedWriter out = new BufferedWriter(fstream);

                out.write("Diameter,Eelec,Iteration,PosX,PosY,E_left\n");

                for ( int i = 0; i < dsc.length - 1; i++ ) {
                    dsc[i].output(out);
                }
                out.close();
            } catch (IOException ex) {
                Logger.getLogger(WSNStart.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    private void outputAlive(dataStorageClass[] dsc, String Type) {
        FileWriter fstream;
        try {
            fstream = new FileWriter(Type + "NumberAlive.csv", true);
            BufferedWriter out = new BufferedWriter(fstream);
            
            out.write("Iteration,numAlive\n");

            for ( int i = 0; i < dsc.length - 1; i++ ) {
                if ( dsc[i].getDiameter() == 50.0 ) {   // Ensure we only output here since this is Figure 5.
                    out.write(i + "," + dsc[i].getNumAlive() + "\n" );
                }
            }
            out.close();
        } catch (IOException ex) {
            Logger.getLogger(WSNStart.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void outputIteration(dataStorageClass[] dsc, int iteration,TransmitType Type) {
        FileWriter fstreamAlive, fstreamDead;
        try {
            if ( iteration == 0 ) {
                fstreamAlive = new FileWriter(Type + "AliveFigure3Data.csv" , true);
                fstreamDead = new FileWriter(Type + "DeadFigure3Data.csv" , true);
            } else if ( iteration == 180 ) {
                fstreamAlive = new FileWriter(Type + "AliveFigure6Data.csv" , true);
                fstreamDead = new FileWriter(Type + "DeadFigure6Data.csv" , true);
            } else {
                fstreamAlive = new FileWriter(Type + "AliveFigure12Data.csv" , true);
                fstreamDead = new FileWriter(Type + "DeadFigure12Data.csv" , true);
            }

            BufferedWriter outAlive = new BufferedWriter(fstreamAlive);
            BufferedWriter outDead = new BufferedWriter(fstreamDead);

            outAlive.write("posX,posY\n");
            outDead.write("posX,posY\n");

            if ( dsc[iteration].getDiameter() == 50.0 ) {
                dsc[iteration].outputBoard(outAlive,outDead);
            }

            outAlive.close();
            outDead.close();
        } catch (IOException ex) {
            Logger.getLogger(WSNStart.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void outputEnergyDissipated(dataStorageClass[] dsc, TransmitType transmitType) {
        FileWriter fstream;
        Double eDissipated = 0.0;
        try {
            fstream = new FileWriter(transmitType + "EnergyDissipated.csv", true);


            BufferedWriter out = new BufferedWriter(fstream);

            eDissipated += dsc[0].getDissipated();

            out.write(dsc[0].getEelec() + "," + dsc[0].getDiameter() + "," + eDissipated + "\n");

            out.close();
        } catch (IOException ex) {
            Logger.getLogger(WSNStart.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void DeleteCSVFile(TransmitType transmitType) throws IOException {
       FileWriter fstream = new FileWriter(transmitType + "NumberAlive.csv");
       fstream = null;

       fstream = new FileWriter(transmitType + "AllData.csv");
       fstream = null;

       fstream = new FileWriter(transmitType + "AliveFigure6Data.csv");
       fstream = null;

       fstream = new FileWriter(transmitType + "DeadFigure6Data.csv");
       fstream = null;


       fstream = new FileWriter(transmitType + "AliveFigure3Data.csv");
       fstream = null;

       fstream = new FileWriter(transmitType + "DeadFigure3Data.csv");
       fstream = null;


       fstream = new FileWriter(transmitType + "EnergyDissipated.csv");
            BufferedWriter out = new BufferedWriter(fstream);
            out.write("Eelec,Diameter,Energy Dissipated\n");
            out.close();
            out = null;
       fstream = null;
    }

    // Created just for the survey of leach for figure 7
    private void outputBoard(Node[] nodes, String subFigure) {
        FileWriter fstream = null, fstream2 = null, fstream3 = null;
            BufferedWriter outAlive = null, outDead = null, outClusterHead = null;
        try {
            fstream = new FileWriter("LeachFigure7" + subFigure + "Alive.csv");
            fstream2 = new FileWriter("LeachFigure7" + subFigure + "Dead.csv");
            fstream3 = new FileWriter("LeachFigure7" + subFigure + "CH.csv");

            outAlive = new BufferedWriter(fstream);
            outDead = new BufferedWriter(fstream2);
            outClusterHead = new BufferedWriter(fstream3);

            for (int i = 0; i < nodes.length - 1; i++) {
                if ( nodes[i].isClusterHead() ) {
                    outClusterHead.write(nodes[i].getPosX() + "," + nodes[i].getPosY() + "\n");
                } else {
                    if (nodes[i].getAlive()) {
                        outAlive.write(nodes[i].getPosX() + "," + nodes[i].getPosY() + "\n");
                    } else {
                        outDead.write(nodes[i].getPosX() + "," + nodes[i].getPosY() + "\n");
                    }
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(WSNThread.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                outAlive.close();
                outDead.close();
                outClusterHead.close();
            } catch (IOException ex) {
                Logger.getLogger(WSNThread.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
