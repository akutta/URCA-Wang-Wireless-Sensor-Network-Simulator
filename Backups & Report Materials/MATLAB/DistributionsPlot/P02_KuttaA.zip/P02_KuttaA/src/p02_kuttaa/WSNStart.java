/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package p02_kuttaa;

import EnumDefinitions.*;

/**
 *
 * @author KuttaA
 */
public class WSNStart {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        WSNStart wsnStart = new WSNStart();
    }

    WSNStart() {
        wsnThread = new WSNThread();
        // SINGLE DETECTION
        //wsnThread.setTransmitType(TransmitType.DIRECT);
        //wsnThread.setTransmitType(TransmitType.MULTIHOP);
        wsnThread.setTransmitType(TransmitType.LEACH);
        //wsnThread.setTransmitType(TransmitType.LEACHSURVEY);

        wsnThread.start();
    }

    WSNThread wsnThread;
}
