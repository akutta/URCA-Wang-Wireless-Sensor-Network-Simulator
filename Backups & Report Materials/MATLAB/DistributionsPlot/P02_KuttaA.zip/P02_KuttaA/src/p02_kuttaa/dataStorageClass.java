/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package p02_kuttaa;

import SensorNodes.*;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 *
 * @author KuttaA
 */
public class dataStorageClass {
    private Integer diameter;
    private Double Eelec;
    private Integer Iteration;
    private Node[][] nodes;
    private Integer curIteration;

    dataStorageClass() {
        curIteration = 0;
        nodes = new Node[11][];    // 100 iterations to properly average out
    }

    void insertNodes(Node[] newNodes) {
        nodes[curIteration] = new Node[newNodes.length];
        for ( int i = 0; i < newNodes.length - 1; i++ ) {
            nodes[curIteration][i] = new WirelessNode(newNodes[i]);
        }
        curIteration++;
    }

    void setIteration(Integer iteration) {
        Iteration = iteration;
    }

    void setDiameter(int diameter) {
        this.diameter = diameter;
    }

    void setEelec(Double Eelec) {
        this.Eelec = Eelec;
    }

    Double getEelec() {
        return Eelec;
    }

    void output(BufferedWriter out) throws IOException {
        Double avgJoules = 0.0;
        for ( int i = 0; i < nodes[0].length - 1; i++ ) {
            out.write(diameter + ",");
            out.write(Eelec + ",");
            out.write(Iteration + ",");
            out.write(nodes[0][i].getPosX() + ","); // Position's Shouldn't Change
            out.write(nodes[0][i].getPosY() + ",");

            for ( Integer j = 0; j < nodes.length - 1; j++ ) {
                avgJoules += nodes[j][i].getJoules();
            }
            avgJoules = avgJoules / nodes.length;
            out.write(avgJoules + "\n");
        }
    }

    double getDiameter() {
        return diameter;
    }

    Integer getNumAlive() {
        Integer iAlive = 0;
        for ( int j = 0; j < nodes.length-1; j++ ) {
            for ( int i = 0; i < nodes[0].length - 1; i++ ) {
                if ( nodes[j][i].getAlive() )
                    iAlive++;
            }
        }
        iAlive /= (nodes.length-1);
        return iAlive;
    }

    void outputBoard(BufferedWriter outAlive, BufferedWriter outDead) throws IOException {
        for ( int i = 0; i < nodes[0].length - 1; i++ ) {
            if ( nodes[0][i].getAlive() ) {
                outAlive.write(nodes[0][i].getPosX() + "," + nodes[0][i].getPosY() + "\n");
            } else {
                outDead.write(nodes[0][i].getPosX() + "," + nodes[0][i].getPosY() + "\n");
            }
        }
    }

    void outputClusterHeads(BufferedWriter out) throws IOException {
        for ( int i = 0; i < nodes[0].length - 1; i++ ) {
            if ( nodes[0][i].isClusterHead() ) {
                out.write(nodes[0][i].getPosX() + "," + nodes[0][i].getPosY() + "\n");
            }
        }
    }

    Double getDissipatedSurvey() {
        Double eDiss = 0.0;
        for ( int i = 0; i < nodes[0].length - 1; i++ ) {
            eDiss += (.5 - nodes[0][i].getJoules());
        }
        return eDiss;
    }

    Double getDissipated() {
        Double eDiss = 0.0;
        for ( int j = 0; j < nodes.length - 1; j++ ) {
            for ( int i = 0; i < nodes[0].length - 1; i++ ) {
                eDiss += ( .5 - nodes[j][i].getJoules() );
            }
        }
        eDiss /= nodes.length;

        return eDiss;
    }
}
