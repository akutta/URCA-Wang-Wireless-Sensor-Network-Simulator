
pDirectA = scatter(randomBoard(:,1),randomBoard(:,2),'o');
hold on
xlabel('X-Coordinate');
ylabel('Y-Coordinate');
legend('Alive');
hold off